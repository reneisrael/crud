<body>
<?php 
	$cabecalho_title = "100 inc&ecirc;ndio";
	include("_menu_cabecalho.php");
?>

<br>
<br>

<div class="container">
    <div class="row">
        <div class="col-md-12">
            <div class="panel panel-primary">
                <div class="panel-heading">
                                    </div>
                <div class="panel-body">
                    <h2>
                        Hello and welcome</h2>
                    <p>
                        Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor
                        incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud
                        exercitation ullamco laboris nisi ut <a href="http://www.jquery2dotnet.com/2013/12/brand-icons-design-using-css.html">Brand Icons Design Using Css</a> aliquip ex ea commodo consequat. Duis aute
                        irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla
                        pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia
                        deserunt mollit anim id est laborum.</p>
                </div>
                <div class="panel-footer">
                    <button type="button" class="btn btn-success">
                        Publish</button>
                    <button type="button" class="btn btn-primary">
                        Save Draft</button>
                    <div class="pull-right">
                        <button type="button" class="btn btn-danger">
                            <i class="fa fa-trash-o"></i> Delete</button>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>


<?php include("_menu_rodape.php");?>
</body>
