<?php
	// conexao BD MySQL
	$host  = "localhost";
	$database = "users"; 
	$login_db = "root";
	$senha_db = "root";
	// fim conexao BD MySQL
?>