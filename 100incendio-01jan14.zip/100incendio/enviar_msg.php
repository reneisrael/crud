<?php/*
 * Arquivo: enviar_msg.php
 * Criado por: Rafaela Vilela
 * Versao: v.1
 * Data: 01.jan.2014
 * Objetivo: Script de envio de msg de contato
 * Parametros: 
 */?>

<?php
// check for form submission - if it doesn't exist then send back to contact form
if (!isset($_POST["save"]) || $_POST["save"] != "contact") {
   # header("Location: formulario_contato.php"); exit;
   include("formulario_contato.php");

	// send the user back to the form
	exit;
}
	
// get the posted data
$name = $_POST["contact_name"];
$email_address = $_POST["contact_email"];
$message = $_POST["contact_message"];

// check that a name was entered
if (empty ($name))
    $msg = "Voc&ecirc; deve digitar seu nome";
    
// check that an email address was entered
elseif (empty ($email_address)) 
    $msg = "Voc&ecirc; deve digitar seu email";
    
// check for a valid email address
elseif (!preg_match("/^[_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,3})$/", $email_address))
    $msg = "Voc&ecirc; deve digitar seu email v&aacute;lido";
    
// check that a message was entered
elseif (empty ($message))
    $msg = "Voc&ecirc; deve digitar sua mensagem.";
		
		
// check if an error was found - if there was, send the user back to the form
if (isset($msg)) {
	$error = -1;
	include("formulario_contato.php");
	exit;
    #header("Location: formulario_contato.php?e=".urlencode($error)); exit;
}

		
// write the email content
$email_content = "Nome: $name\n";
$email_content .= "Email: $email_address\n";
$email_content .= "Mensagem:\n\n$message";
	
// send the email
$envio = mail ("rafaela.vilela@gmail.com", "Nova Mensagem de Contato", $email_content);

	if($envio){
 		$error = 1;
		$msg = "Mensagem enviada. <br> Entraremos em contato em breve.  <br> <strong> Obrigado. </strong>";
		#header("Location: formulario_contato.php?s=".urlencode("Mensagem enviada. Entraremos em contato em breve. Obrigado.")); 
	} 
	else {
		$error = -1;
		$msg = "A mensagem n�o pode ser enviada";
 		#echo("Location: formulario_contato.php?e=".urlencode("A mensagem n�o pode ser enviada"));;
 	} #if-else envio
 	
	include("formulario_contato.php");

	// send the user back to the form
	exit;

?>
