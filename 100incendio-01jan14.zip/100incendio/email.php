<?php
mail(
  'rafaela.vilela@gmail.com', // your email address
  'Test', // email subject
  'This is an email', // email body
  "From: Me <me@mydomain.com>rn" // additional headers
);
?>